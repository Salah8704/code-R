# Code Route — Application complète

Préparation au code de la route avec méthode structurée, algorithme adaptatif et paiement Stripe.

## Stack
- **Next.js 15** (App Router)
- **TypeScript** strict
- **Tailwind CSS** avec couleurs brand
- **Prisma** + PostgreSQL
- **NextAuth v4** (credentials)
- **Stripe** (abonnement mensuel)
- **bcryptjs** (hash des mots de passe)

---

## Structure des fichiers modifiés / ajoutés

```
app/
├── page.tsx                        # ✅ Landing page marketing complète
├── layout.tsx                      # ✅ RootLayout avec SessionProvider
├── globals.css                     # (inchangé)
├── auth/
│   ├── login/page.tsx              # ✅ Page de connexion
│   └── register/page.tsx           # ✅ Page d'inscription
├── dashboard/page.tsx              # ✅ Dashboard connecté aux données réelles
├── quiz/page.tsx                   # ✅ Moteur de quiz complet
├── pricing/page.tsx                # ✅ Page tarifs avec Stripe
├── admin/page.tsx                  # ✅ Interface admin (questions)
└── api/
    ├── auth/
    │   ├── [...nextauth]/route.ts  # ✅ NextAuth (credentials)
    │   └── register/route.ts      # ✅ Inscription utilisateur
    ├── checkout/route.ts           # ✅ Stripe Checkout Session
    ├── webhook/route.ts            # ✅ Stripe Webhook
    ├── quiz/
    │   ├── start/route.ts          # ✅ Démarrer une série (20 questions)
    │   ├── answer/route.ts         # ✅ Soumettre une réponse
    │   └── complete/route.ts       # ✅ Terminer une série + logique pause
    ├── dashboard/route.ts          # ✅ Données dashboard réelles
    └── admin/questions/route.ts    # ✅ CRUD questions (admin)

components/
└── SessionProvider.tsx             # ✅ Wrapper NextAuth client

lib/
├── prisma.ts                       # ✅ Singleton PrismaClient
└── algorithm.ts                    # ✅ Logique métier (weaknessDelta, readiness)

middleware.ts                       # ✅ Protection des routes (JWT)
types/next-auth.d.ts                # ✅ Extension des types Session/JWT
```

---

## Installation

### 1. Copier les variables d'environnement
```bash
cp .env.example .env
```

Renseigner `.env` :
```env
DATABASE_URL="postgresql://USER:PASSWORD@HOST:5432/code_route"
NEXTAUTH_URL="http://localhost:3000"
NEXTAUTH_SECRET="une-chaine-longue-et-aleatoire"
STRIPE_SECRET_KEY="sk_test_xxx"
NEXT_PUBLIC_STRIPE_PRICE_ID="price_xxx"
STRIPE_WEBHOOK_SECRET="whsec_xxx"
```

### 2. Installer les dépendances
```bash
npm install
```

### 3. Créer la base de données
```bash
npm run db:push
```

### 4. Seeder les questions
```bash
npm run seed
```

### 5. Lancer en développement
```bash
npm run dev
```

---

## Configuration Stripe

### Créer un produit et un prix
1. Connecte-toi sur [dashboard.stripe.com](https://dashboard.stripe.com)
2. Créer un produit "Code Route Premium" → abonnement mensuel 19 €
3. Copier le **Price ID** → `NEXT_PUBLIC_STRIPE_PRICE_ID`

### Configurer le webhook local (test)
```bash
stripe listen --forward-to localhost:3000/api/webhook
```
Copier le `whsec_xxx` affiché → `STRIPE_WEBHOOK_SECRET`

### En production
Dans le dashboard Stripe → Webhooks → Ajouter un endpoint :
- URL : `https://ton-domaine.com/api/webhook`
- Événements : `checkout.session.completed`, `customer.subscription.deleted`

---

## Créer un compte admin

Après avoir créé un compte via `/auth/register`, mettre à jour le rôle en base :

```bash
npx prisma studio
```
Trouver l'utilisateur dans la table `User`, changer `role` à `"admin"`.

Ou via SQL :
```sql
UPDATE "User" SET role = 'admin' WHERE email = 'ton@email.com';
```

Accéder ensuite à `/admin`.

---

## Flux utilisateur

```
/ (landing)
  → /auth/register (inscription)
  → /dashboard (connecté)
      → /quiz (série de 20 questions)
          → Question par question
          → Correction immédiate + explication
          → Fin de série → 2e série ou pause
      → /pricing → Stripe Checkout → paiement → /dashboard?success=1
```

---

## Logique métier — Blocs et pause

1. Un **bloc** = 2 séries
2. Après 2 séries, `shouldForcePause()` retourne `true`
3. `/api/quiz/complete` crée un `BlockPause` avec `endAt = now + 30 min`
4. `/api/quiz/start` retourne HTTP 423 si une pause est active
5. Le quiz affiche l'écran `PauseScreen` avec minuteur en temps réel
6. Après la pause, un nouveau `StudyBlock` est créé

---

## Logique métier — Algorithme adaptatif

Chaque réponse met à jour `WeaknessScore` par `trapFamily` :

| Cas | Delta |
|-----|-------|
| Mauvaise réponse | +3 × base |
| Bonne réponse | −1 × base |
| Lent (>15s) | +1 × base |
| Erreur répétée | +1.5 × base |

où `base = 1 + 0.25 × (difficulté − 1)`

Les 20 questions de la prochaine série sont tirées **en priorité** des trapFamilies avec les scores les plus élevés.

---

## Tests rapides

| URL | Action |
|-----|--------|
| `/` | Landing page marketing |
| `/auth/register` | Créer un compte |
| `/auth/login` | Se connecter |
| `/dashboard` | Dashboard (données réelles) |
| `/quiz` | Faire une série |
| `/pricing` | Voir les tarifs + Stripe |
| `/admin` | Admin (rôle admin requis) |

---

## Déploiement (Hostinger / Vercel)

```bash
npm run build
npm run start
```

Variables d'environnement requises en production :
- `DATABASE_URL`
- `NEXTAUTH_URL` (URL publique du site)
- `NEXTAUTH_SECRET`
- `STRIPE_SECRET_KEY` (clé live `sk_live_xxx`)
- `NEXT_PUBLIC_STRIPE_PRICE_ID`
- `STRIPE_WEBHOOK_SECRET`
