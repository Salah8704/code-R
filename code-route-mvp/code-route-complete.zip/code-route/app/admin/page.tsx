"use client";
import { useEffect, useState, FormEvent } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Plus, Trash2 } from "lucide-react";

type Choice = { id: string; text: string; isCorrect: boolean };
type Question = {
  id: string;
  theme: string;
  subtheme: string;
  trapFamily: string;
  difficulty: number;
  prompt: string;
  choices: Choice[];
};

const EMPTY_FORM = {
  theme: "",
  subtheme: "",
  trapFamily: "",
  difficulty: 1,
  prompt: "",
  explanationShort: "",
  choices: [
    { text: "", isCorrect: false },
    { text: "", isCorrect: false },
    { text: "", isCorrect: true },
  ],
};

export default function AdminPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [questions, setQuestions] = useState<Question[]>([]);
  const [form, setForm] = useState(EMPTY_FORM);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    if (status === "loading") return;
    if (!session || session.user.role !== "admin") {
      router.push("/dashboard");
      return;
    }
    fetchQuestions();
  }, [session, status, router]);

  async function fetchQuestions() {
    const res = await fetch("/api/admin/questions");
    if (res.ok) {
      const data = await res.json();
      setQuestions(data);
    }
    setLoading(false);
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setSaving(true);
    setMsg("");

    const res = await fetch("/api/admin/questions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });

    setSaving(false);

    if (res.ok) {
      const q = await res.json();
      setQuestions((prev) => [q, ...prev]);
      setForm(EMPTY_FORM);
      setMsg("✓ Question ajoutée avec succès");
    } else {
      setMsg("✗ Erreur lors de l'ajout");
    }
  }

  function updateChoice(index: number, field: "text" | "isCorrect", value: string | boolean) {
    setForm((prev) => ({
      ...prev,
      choices: prev.choices.map((c, i) =>
        i === index ? { ...c, [field]: value } : c
      ),
    }));
  }

  function addChoice() {
    setForm((prev) => ({
      ...prev,
      choices: [...prev.choices, { text: "", isCorrect: false }],
    }));
  }

  function removeChoice(index: number) {
    setForm((prev) => ({
      ...prev,
      choices: prev.choices.filter((_, i) => i !== index),
    }));
  }

  if (loading) return <div className="p-8 text-slate-400">Chargement…</div>;

  return (
    <main className="min-h-screen bg-slate-50">
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-4">
          <Link href="/" className="text-lg font-bold text-brand">Code Route</Link>
          <span className="rounded-full bg-red-100 px-3 py-1 text-xs font-semibold text-red-700">Admin</span>
        </div>
      </header>

      <div className="mx-auto max-w-5xl px-6 py-10">
        <div className="grid gap-8 lg:grid-cols-2">
          {/* Add question form */}
          <div className="rounded-2xl border border-slate-200 bg-white p-6">
            <h2 className="text-lg font-semibold text-slate-900">Ajouter une question</h2>

            {msg && (
              <div className={`mt-3 rounded-lg px-4 py-2 text-sm ${msg.startsWith("✓") ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"}`}>
                {msg}
              </div>
            )}

            <form onSubmit={handleSubmit} className="mt-4 space-y-4">
              <Field label="Question (prompt)">
                <textarea
                  rows={3}
                  value={form.prompt}
                  onChange={(e) => setForm((p) => ({ ...p, prompt: e.target.value }))}
                  required
                  className="input"
                  placeholder="J'arrive à une intersection…"
                />
              </Field>

              <div className="grid grid-cols-2 gap-3">
                <Field label="Thème">
                  <input
                    value={form.theme}
                    onChange={(e) => setForm((p) => ({ ...p, theme: e.target.value }))}
                    required
                    className="input"
                    placeholder="priorites"
                  />
                </Field>
                <Field label="Sous-thème">
                  <input
                    value={form.subtheme}
                    onChange={(e) => setForm((p) => ({ ...p, subtheme: e.target.value }))}
                    required
                    className="input"
                    placeholder="priorite_a_droite"
                  />
                </Field>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <Field label="Famille de piège">
                  <input
                    value={form.trapFamily}
                    onChange={(e) => setForm((p) => ({ ...p, trapFamily: e.target.value }))}
                    required
                    className="input"
                    placeholder="priorite_implicite"
                  />
                </Field>
                <Field label="Difficulté">
                  <select
                    value={form.difficulty}
                    onChange={(e) => setForm((p) => ({ ...p, difficulty: Number(e.target.value) }))}
                    className="input"
                  >
                    <option value={1}>1 — Facile</option>
                    <option value={2}>2 — Moyen</option>
                    <option value={3}>3 — Difficile</option>
                  </select>
                </Field>
              </div>

              <Field label="Explication courte">
                <input
                  value={form.explanationShort}
                  onChange={(e) => setForm((p) => ({ ...p, explanationShort: e.target.value }))}
                  required
                  className="input"
                  placeholder="Sans signalisation, la priorité à droite s'applique."
                />
              </Field>

              <div>
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium text-slate-700">Choix</label>
                  <button
                    type="button"
                    onClick={addChoice}
                    className="flex items-center gap-1 text-xs text-brand hover:underline"
                  >
                    <Plus className="h-3 w-3" />
                    Ajouter
                  </button>
                </div>
                <div className="mt-2 space-y-2">
                  {form.choices.map((c, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={c.isCorrect}
                        onChange={(e) => updateChoice(i, "isCorrect", e.target.checked)}
                        title="Correct ?"
                        className="h-4 w-4 accent-brand"
                      />
                      <input
                        value={c.text}
                        onChange={(e) => updateChoice(i, "text", e.target.value)}
                        required
                        className="input flex-1"
                        placeholder={`Choix ${i + 1}`}
                      />
                      {form.choices.length > 2 && (
                        <button
                          type="button"
                          onClick={() => removeChoice(i)}
                          className="text-slate-300 hover:text-red-400"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                  ))}
                  <p className="text-xs text-slate-400">Coche la (les) réponse(s) correcte(s)</p>
                </div>
              </div>

              <button
                type="submit"
                disabled={saving}
                className="w-full rounded-xl bg-brand py-2.5 text-sm font-semibold text-white hover:bg-brand-dark disabled:opacity-60 transition-colors"
              >
                {saving ? "Enregistrement…" : "Ajouter la question"}
              </button>
            </form>
          </div>

          {/* Question list */}
          <div>
            <h2 className="mb-4 text-lg font-semibold text-slate-900">
              Questions ({questions.length})
            </h2>
            <div className="space-y-3 max-h-[700px] overflow-y-auto pr-1">
              {questions.map((q) => (
                <div key={q.id} className="rounded-xl border border-slate-200 bg-white p-4">
                  <div className="flex items-start justify-between gap-2">
                    <p className="text-sm font-medium text-slate-800 leading-snug">{q.prompt}</p>
                    <span className="flex-shrink-0 rounded-full bg-slate-100 px-2 py-0.5 text-xs text-slate-500">
                      {q.difficulty}/3
                    </span>
                  </div>
                  <div className="mt-2 flex gap-2">
                    <span className="rounded-full bg-brand/10 px-2 py-0.5 text-xs text-brand">{q.theme}</span>
                    <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs text-slate-500">{q.trapFamily}</span>
                  </div>
                  <div className="mt-2 space-y-1">
                    {q.choices.map((c) => (
                      <p key={c.id} className={`text-xs ${c.isCorrect ? "text-green-600 font-medium" : "text-slate-400"}`}>
                        {c.isCorrect ? "✓" : "○"} {c.text}
                      </p>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        .input {
          display: block;
          width: 100%;
          border-radius: 0.5rem;
          border: 1px solid #cbd5e1;
          padding: 0.5rem 0.75rem;
          font-size: 0.875rem;
          outline: none;
        }
        .input:focus {
          border-color: #0f766e;
          box-shadow: 0 0 0 1px #0f766e;
        }
      `}</style>
    </main>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="mb-1 block text-sm font-medium text-slate-700">{label}</label>
      {children}
    </div>
  );
}
