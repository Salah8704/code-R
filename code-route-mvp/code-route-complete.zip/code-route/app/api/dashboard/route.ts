import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { prisma } from "@/lib/prisma";
import { readinessScore, readinessLabel } from "@/lib/algorithm";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });

  const userId = session.user.id;

  // Current active block
  const block = await prisma.studyBlock.findFirst({
    where: { userId, status: "active" },
    orderBy: { startedAt: "desc" },
    include: {
      pauses: { where: { status: "active" }, orderBy: { startAt: "desc" }, take: 1 },
    },
  });

  // All completed series
  const allSeries = await prisma.series.findMany({
    where: { userId, endedAt: { not: null } },
    include: { items: { include: { question: true } } },
    orderBy: { startedAt: "desc" },
  });

  // Recent attempts to compute score
  const recentAttempts = await prisma.attempt.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
    take: 200,
  });

  const totalAttempts = recentAttempts.length;
  const correctAttempts = recentAttempts.filter((a) => a.isCorrect).length;
  const globalAccuracy = totalAttempts > 0 ? Math.round((correctAttempts / totalAttempts) * 40) : 0;

  // Top weakness traps
  const weaknesses = await prisma.weaknessScore.findMany({
    where: { userId },
    orderBy: { score: "desc" },
    take: 5,
  });

  // Compute readiness
  const seriesScores = allSeries.map((s) => {
    const items = s.items;
    if (!items.length) return 0;
    // We'd need attempt results per series — approximate from total accuracy
    return globalAccuracy;
  });

  const trapMastery =
    weaknesses.length > 0
      ? Math.max(0, 1 - weaknesses.slice(0, 3).reduce((a, w) => a + w.score, 0) / 100)
      : 0.5;

  const rScore =
    seriesScores.length > 0
      ? readinessScore(seriesScores, trapMastery, 0.5, 0.5)
      : 0;

  const rLabel = readinessLabel(rScore);

  const activePause = block?.pauses?.[0];
  const pauseActive = activePause ? new Date() < activePause.endAt : false;

  return NextResponse.json({
    currentBlock: block
      ? {
          id: block.id,
          blockNumber: block.blockNumber,
          seriesCompleted: block.seriesCompleted,
        }
      : null,
    pause: pauseActive
      ? {
          active: true,
          resumeAt: activePause!.endAt,
          pauseId: activePause!.id,
        }
      : { active: false },
    globalScore: globalAccuracy,
    readinessScore: rScore,
    readinessLabel: rLabel,
    totalSeries: allSeries.length,
    topTraps: weaknesses.map((w) => ({ name: w.key, score: Math.round(w.score) })),
    nextAction: pauseActive
      ? "Pause en cours. Repose-toi, c'est important !"
      : block && block.seriesCompleted < 2
      ? "Fais ta deuxième série pour terminer le bloc."
      : "Commence un nouveau bloc dès que tu es prêt.",
  });
}
