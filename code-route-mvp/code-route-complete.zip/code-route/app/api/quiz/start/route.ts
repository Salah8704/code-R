import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { prisma } from "@/lib/prisma";
import { shouldForcePause } from "@/lib/algorithm";

// POST /api/quiz/start → create a new Series with 20 questions
export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });

  const userId = session.user.id;

  // Find or create the current active StudyBlock
  let block = await prisma.studyBlock.findFirst({
    where: { userId, status: "active" },
    orderBy: { startedAt: "desc" },
  });

  // Check if forced pause applies
  if (block && shouldForcePause(block.seriesCompleted)) {
    // Check if there's an active pause
    const pause = await prisma.blockPause.findFirst({
      where: { studyBlockId: block.id, status: "active" },
    });
    if (pause && new Date() < pause.endAt) {
      return NextResponse.json({ pauseUntil: pause.endAt }, { status: 423 });
    }
    // Pause expired → close old block, create new one
    await prisma.studyBlock.update({ where: { id: block.id }, data: { status: "completed", endedAt: new Date() } });
    block = null;
  }

  if (!block) {
    // Count completed blocks to get block number
    const blockCount = await prisma.studyBlock.count({ where: { userId } });
    block = await prisma.studyBlock.create({
      data: { userId, blockNumber: blockCount + 1 },
    });
  }

  // Select 20 questions, prioritising weak areas
  const weaknesses = await prisma.weaknessScore.findMany({
    where: { userId },
    orderBy: { score: "desc" },
    take: 5,
  });

  const weakKeys = weaknesses.map((w) => w.key);

  // Get already-seen question IDs in this block's series
  const seriesInBlock = await prisma.series.findMany({
    where: { studyBlockId: block.id },
    include: { items: { select: { questionId: true } } },
  });
  const seenIds = seriesInBlock.flatMap((s) => s.items.map((i) => i.questionId));

  // Try to get weak-area questions first
  let questions = weakKeys.length
    ? await prisma.question.findMany({
        where: { trapFamily: { in: weakKeys }, id: { notIn: seenIds } },
        take: 10,
        include: { choices: { orderBy: { position: "asc" } } },
      })
    : [];

  // Fill up to 20 with random questions not yet seen
  if (questions.length < 20) {
    const existing = questions.map((q) => q.id);
    const fill = await prisma.question.findMany({
      where: { id: { notIn: [...seenIds, ...existing] } },
      take: 20 - questions.length,
      include: { choices: { orderBy: { position: "asc" } } },
    });
    questions = [...questions, ...fill];
  }

  // If still short, allow repeats
  if (questions.length < 20) {
    const existing = questions.map((q) => q.id);
    const fill = await prisma.question.findMany({
      where: { id: { notIn: existing } },
      take: 20 - questions.length,
      include: { choices: { orderBy: { position: "asc" } } },
    });
    questions = [...questions, ...fill];
  }

  // Shuffle
  questions = questions.sort(() => Math.random() - 0.5).slice(0, 20);

  // Create Series
  const series = await prisma.series.create({
    data: {
      userId,
      mode: "training",
      plannedCount: questions.length,
      studyBlockId: block.id,
      items: {
        create: questions.map((q, i) => ({
          id: `${Date.now()}_${i}`,
          questionId: q.id,
          position: i,
        })),
      },
    },
  });

  // Strip isCorrect from choices before sending to client
  const sanitizedQuestions = questions.map((q) => ({
    ...q,
    choices: q.choices.map(({ isCorrect: _, ...c }) => c),
  }));

  return NextResponse.json({ seriesId: series.id, blockId: block.id, questions: sanitizedQuestions });
}
