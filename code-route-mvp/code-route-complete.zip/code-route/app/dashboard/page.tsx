"use client";
import { useEffect, useState } from "react";
import { useSession, signOut } from "next-auth/react";
import Link from "next/link";
import { BarChart2, Clock, Zap, AlertTriangle, LogOut, Play } from "lucide-react";

type DashboardData = {
  currentBlock: { id: string; blockNumber: number; seriesCompleted: number } | null;
  pause: { active: boolean; resumeAt?: string; pauseId?: string };
  globalScore: number;
  readinessScore: number;
  readinessLabel: string;
  totalSeries: number;
  topTraps: { name: string; score: number }[];
  nextAction: string;
};

function PauseCountdown({ resumeAt }: { resumeAt: string }) {
  const [remaining, setRemaining] = useState("");

  useEffect(() => {
    const tick = () => {
      const diff = new Date(resumeAt).getTime() - Date.now();
      if (diff <= 0) {
        setRemaining("Pause terminée !");
        return;
      }
      const m = Math.floor(diff / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      setRemaining(`${m}:${s.toString().padStart(2, "0")}`);
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [resumeAt]);

  return <span className="font-mono text-2xl font-bold text-brand">{remaining}</span>;
}

export default function DashboardPage() {
  const { data: session } = useSession();
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/dashboard")
      .then((r) => r.json())
      .then((d) => {
        setData(d);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50">
        <div className="text-slate-400">Chargement…</div>
      </div>
    );
  }

  const canStartQuiz = !data?.pause.active;

  return (
    <main className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-4">
          <Link href="/" className="text-lg font-bold text-brand">Code Route</Link>
          <div className="flex items-center gap-4">
            <span className="text-sm text-slate-500">{session?.user.email}</span>
            <button
              onClick={() => signOut({ callbackUrl: "/" })}
              className="flex items-center gap-1.5 text-sm text-slate-400 hover:text-slate-700 transition-colors"
            >
              <LogOut className="h-4 w-4" />
              Déconnexion
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-5xl px-6 py-10">
        {/* Pause banner */}
        {data?.pause.active && data.pause.resumeAt && (
          <div className="mb-8 rounded-2xl border border-orange-200 bg-orange-50 p-6">
            <div className="flex items-center gap-3">
              <Clock className="h-6 w-6 text-orange-500" />
              <div>
                <p className="font-semibold text-orange-800">Pause de 30 minutes en cours</p>
                <p className="text-sm text-orange-600">
                  Reprends dans <PauseCountdown resumeAt={data.pause.resumeAt} />
                </p>
                <p className="mt-2 text-sm text-orange-700">
                  La pause permet à ton cerveau de consolider ce que tu viens d&apos;apprendre.
                  C&apos;est une partie essentielle de la méthode. Profites-en pour bouger !
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Next action */}
        {data && (
          <div className="mb-8 flex items-center justify-between rounded-2xl bg-brand px-6 py-5 text-white">
            <div>
              <p className="text-sm font-medium text-brand-light">Prochaine action</p>
              <p className="mt-0.5 font-semibold">{data.nextAction}</p>
            </div>
            {canStartQuiz ? (
              <Link
                href="/quiz"
                className="flex items-center gap-2 rounded-xl bg-white px-5 py-2.5 text-sm font-semibold text-brand hover:bg-brand-light transition-colors"
              >
                <Play className="h-4 w-4" />
                Commencer une série
              </Link>
            ) : (
              <button
                disabled
                className="flex items-center gap-2 rounded-xl bg-white/20 px-5 py-2.5 text-sm font-semibold text-white/60 cursor-not-allowed"
              >
                <Clock className="h-4 w-4" />
                En pause
              </button>
            )}
          </div>
        )}

        {/* Stats grid */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard
            icon={<BarChart2 className="h-5 w-5" />}
            label="Score de préparation"
            value={data ? `${data.readinessScore}/100` : "—"}
            sub={data?.readinessLabel}
          />
          <StatCard
            icon={<Zap className="h-5 w-5" />}
            label="Bloc actuel"
            value={data?.currentBlock ? `Bloc ${data.currentBlock.blockNumber}` : "—"}
            sub={
              data?.currentBlock
                ? `${data.currentBlock.seriesCompleted}/2 séries`
                : "Aucun bloc actif"
            }
          />
          <StatCard
            icon={<BarChart2 className="h-5 w-5" />}
            label="Score moyen"
            value={data ? `${data.globalScore}/40` : "—"}
            sub="sur toutes tes séries"
          />
          <StatCard
            icon={<Clock className="h-5 w-5" />}
            label="Séries totales"
            value={data ? `${data.totalSeries}` : "0"}
            sub="séries complétées"
          />
        </div>

        {/* Block progress */}
        {data?.currentBlock && (
          <div className="mt-6 rounded-2xl border border-slate-200 bg-white p-6">
            <h2 className="font-semibold text-slate-900">
              Bloc {data.currentBlock.blockNumber} — Progression
            </h2>
            <div className="mt-4 flex gap-3">
              {[1, 2].map((n) => (
                <div
                  key={n}
                  className={`flex h-16 flex-1 items-center justify-center rounded-xl text-sm font-medium ${
                    n <= data.currentBlock!.seriesCompleted
                      ? "bg-brand text-white"
                      : "border border-dashed border-slate-300 text-slate-400"
                  }`}
                >
                  {n <= data.currentBlock!.seriesCompleted ? `✓ Série ${n}` : `Série ${n}`}
                </div>
              ))}
            </div>
            {data.pause.active && (
              <p className="mt-3 text-center text-sm text-orange-600">
                ⏸ Pause obligatoire jusqu&apos;à{" "}
                {data.pause.resumeAt
                  ? new Date(data.pause.resumeAt).toLocaleTimeString("fr-FR", {
                      hour: "2-digit",
                      minute: "2-digit",
                    })
                  : "bientôt"}
              </p>
            )}
          </div>
        )}

        {/* Top traps */}
        {data && data.topTraps.length > 0 && (
          <div className="mt-6 rounded-2xl border border-slate-200 bg-white p-6">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-orange-500" />
              <h2 className="font-semibold text-slate-900">Points faibles à travailler</h2>
            </div>
            <div className="mt-4 space-y-3">
              {data.topTraps.map((trap) => (
                <div key={trap.name} className="flex items-center gap-3">
                  <span className="w-48 truncate text-sm text-slate-600">{trap.name.replace(/_/g, " ")}</span>
                  <div className="flex-1 overflow-hidden rounded-full bg-slate-100 h-2">
                    <div
                      className="h-full rounded-full bg-orange-400"
                      style={{ width: `${Math.min(100, (trap.score / 30) * 100)}%` }}
                    />
                  </div>
                  <span className="text-sm font-medium text-slate-500">{trap.score}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Empty state */}
        {data && data.totalSeries === 0 && (
          <div className="mt-8 rounded-2xl border border-dashed border-slate-300 p-12 text-center">
            <p className="text-slate-500">Tu n&apos;as pas encore fait de série.</p>
            <Link href="/quiz" className="mt-4 inline-block rounded-lg bg-brand px-5 py-2.5 text-sm font-semibold text-white hover:bg-brand-dark transition-colors">
              Commencer ma première série
            </Link>
          </div>
        )}
      </div>
    </main>
  );
}

function StatCard({
  icon,
  label,
  value,
  sub,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  sub?: string;
}) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5">
      <div className="flex items-center gap-2 text-slate-400">{icon}<span className="text-xs">{label}</span></div>
      <p className="mt-2 text-2xl font-bold text-slate-900">{value}</p>
      {sub && <p className="text-xs text-slate-400">{sub}</p>}
    </div>
  );
}
