import Link from "next/link";
import { CheckCircle, Clock, BarChart2, Zap, Shield, ChevronRight, Star } from "lucide-react";

export const metadata = {
  title: "Code Route — Réussis le code en 3 semaines avec une méthode structurée",
  description:
    "Prépare-toi au code de la route avec 2 séries structurées, une pause de 30 minutes et un algorithme qui s'adapte à tes erreurs. Méthode scientifique, résultats concrets.",
};

const TESTIMONIALS = [
  {
    name: "Mathieu R.",
    score: "39/40",
    text: "J'avais déjà raté deux fois. Avec Code Route, j'ai eu 39/40 au bout de 18 jours. La méthode des blocs m'a vraiment aidé à ne pas me noyer.",
  },
  {
    name: "Léa T.",
    score: "40/40",
    text: "Je recommande à tous mes amis. Les questions pièges m'ont préparée à exactement ce qui tombait à l'examen.",
  },
  {
    name: "Kévin M.",
    score: "38/40",
    text: "La pause de 30 minutes m'a semblé inutile au début… mais après j'ai vraiment vu la différence. Mon cerveau retenait mieux.",
  },
];

const STEPS = [
  {
    number: "01",
    title: "Commence une série de 20 questions",
    desc: "Chaque question est sélectionnée selon tes points faibles actuels. Les premières séries couvrent l'essentiel.",
  },
  {
    number: "02",
    title: "Analyse tes erreurs après chaque question",
    desc: "La correction apparaît immédiatement avec une explication courte et une explication longue si tu veux creuser.",
  },
  {
    number: "03",
    title: "Fais ta deuxième série pour terminer le bloc",
    desc: "Un bloc = 2 séries. La deuxième série reprend les thèmes où tu as échoué dans la première.",
  },
  {
    number: "04",
    title: "Pause obligatoire de 30 minutes",
    desc: "La science de l'apprentissage est claire : la consolidation se fait pendant le repos. On te bloque pour que tu respectes ça.",
  },
];

const DIFFERENTIATORS = [
  {
    icon: <Zap className="h-5 w-5" />,
    title: "Questions pièges identifiées",
    desc: "540 questions classées par famille de pièges. Tu apprends à reconnaître les patterns, pas juste à mémoriser.",
  },
  {
    icon: <BarChart2 className="h-5 w-5" />,
    title: "Score de préparation en temps réel",
    desc: "Ton readiness score évolue après chaque série. Tu sais précisément si tu es prêt à passer l'examen.",
  },
  {
    icon: <Clock className="h-5 w-5" />,
    title: "Pause forcée après 2 séries",
    desc: "Pas de marathon contre-productif. La méthode t'impose un repos de 30 minutes entre les blocs.",
  },
  {
    icon: <Shield className="h-5 w-5" />,
    title: "Algorithme adaptatif",
    desc: "Les questions que tu rates reviennent plus souvent. Celles que tu maîtrises s'espacent naturellement.",
  },
];

export default function HomePage() {
  return (
    <main className="min-h-screen bg-slate-50 font-sans antialiased">
      {/* NAV */}
      <nav className="sticky top-0 z-50 border-b border-slate-200 bg-white/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <span className="text-lg font-bold tracking-tight text-brand">Code Route</span>
          <div className="flex items-center gap-4">
            <Link href="/pricing" className="hidden text-sm text-slate-600 hover:text-slate-900 sm:block">
              Tarifs
            </Link>
            <Link href="/auth/login" className="text-sm text-slate-600 hover:text-slate-900">
              Connexion
            </Link>
            <Link
              href="/auth/register"
              className="rounded-lg bg-brand px-4 py-2 text-sm font-medium text-white hover:bg-brand-dark transition-colors"
            >
              Commencer
            </Link>
          </div>
        </div>
      </nav>

      {/* HERO */}
      <section className="mx-auto max-w-6xl px-6 py-24">
        <div className="max-w-3xl">
          <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-brand/30 bg-brand/5 px-3 py-1 text-sm font-medium text-brand">
            <CheckCircle className="h-4 w-4" />
            Méthode structurée · 540 questions · Algorithme adaptatif
          </p>
          <h1 className="text-5xl font-extrabold leading-tight tracking-tight text-slate-900 sm:text-6xl">
            Réussis le code en{" "}
            <span className="text-brand">3 semaines</span>{" "}
            avec une méthode structurée
          </h1>
          <p className="mt-6 text-xl text-slate-600">
            2 séries par bloc · pause de 30 minutes · correction immédiate · questions pièges identifiées.
            Une préparation scientifique pour un résultat prévisible.
          </p>
          <div className="mt-10 flex flex-wrap gap-4">
            <Link
              href="/auth/register"
              className="inline-flex items-center gap-2 rounded-xl bg-brand px-6 py-3.5 font-semibold text-white shadow-md hover:bg-brand-dark transition-colors"
            >
              Commencer gratuitement
              <ChevronRight className="h-4 w-4" />
            </Link>
            <Link
              href="/pricing"
              className="inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-6 py-3.5 font-semibold text-slate-700 hover:border-slate-400 transition-colors"
            >
              Voir les tarifs
            </Link>
          </div>
          <p className="mt-4 text-sm text-slate-400">Sans carte bancaire pour commencer · Accès immédiat</p>
        </div>
      </section>

      {/* STATS */}
      <section className="border-y border-slate-200 bg-white">
        <div className="mx-auto grid max-w-6xl grid-cols-2 divide-x divide-slate-200 px-6 sm:grid-cols-4">
          {[
            { value: "540", label: "questions originales" },
            { value: "3 sem.", label: "pour être prêt" },
            { value: "38/40", label: "score moyen des finissants" },
            { value: "95%", label: "de taux de réussite" },
          ].map((s) => (
            <div key={s.label} className="py-8 text-center">
              <p className="text-3xl font-extrabold text-brand">{s.value}</p>
              <p className="mt-1 text-sm text-slate-500">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* COMMENT ÇA MARCHE */}
      <section className="mx-auto max-w-6xl px-6 py-24">
        <div className="mb-16 text-center">
          <h2 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">
            Comment ça marche
          </h2>
          <p className="mt-3 text-slate-500">Une session = un bloc = deux séries + une pause.</p>
        </div>
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {STEPS.map((step) => (
            <div key={step.number} className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
              <p className="text-4xl font-black text-brand/20">{step.number}</p>
              <h3 className="mt-3 font-semibold text-slate-900">{step.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-500">{step.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* POURQUOI C'EST DIFFÉRENT */}
      <section className="bg-slate-900 py-24 text-white">
        <div className="mx-auto max-w-6xl px-6">
          <div className="mb-16 text-center">
            <h2 className="text-3xl font-bold sm:text-4xl">Pourquoi c&apos;est différent</h2>
            <p className="mt-3 text-slate-400">
              Pas un bête recueil de questions. Un système d&apos;apprentissage.
            </p>
          </div>
          <div className="grid gap-6 sm:grid-cols-2">
            {DIFFERENTIATORS.map((d) => (
              <div
                key={d.title}
                className="rounded-2xl border border-slate-700 bg-slate-800 p-6"
              >
                <div className="mb-3 inline-flex h-10 w-10 items-center justify-center rounded-xl bg-brand/20 text-brand">
                  {d.icon}
                </div>
                <h3 className="font-semibold text-white">{d.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-400">{d.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PROGRESSION */}
      <section className="mx-auto max-w-6xl px-6 py-24">
        <div className="grid items-center gap-16 lg:grid-cols-2">
          <div>
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
              Une progression visible jour après jour
            </h2>
            <p className="mt-4 text-slate-500">
              Ton tableau de bord affiche ton score de préparation (readiness), les thèmes à risque,
              le bloc en cours et les pièges récurrents. Tu sais toujours où tu en es.
            </p>
            <ul className="mt-6 space-y-3">
              {[
                "Score de préparation de 0 à 100",
                "Bloc actuel et séries réalisées",
                "Top 3 des familles de pièges à travailler",
                "Historique des séries et scores",
              ].map((item) => (
                <li key={item} className="flex items-center gap-3 text-sm text-slate-700">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 text-brand" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
            {/* Dashboard preview mockup */}
            <div className="mb-4 flex items-center justify-between">
              <span className="text-sm font-medium text-slate-500">Score de préparation</span>
              <span className="rounded-full bg-brand/10 px-3 py-1 text-sm font-bold text-brand">Presque prêt</span>
            </div>
            <div className="relative h-4 overflow-hidden rounded-full bg-slate-100">
              <div className="h-full w-[72%] rounded-full bg-gradient-to-r from-brand to-teal-400" />
            </div>
            <p className="mt-1 text-right text-2xl font-black text-slate-900">72 / 100</p>
            <div className="mt-6 grid grid-cols-3 gap-3">
              {[
                { label: "Bloc actuel", value: "Bloc 3" },
                { label: "Séries faites", value: "1 / 2" },
                { label: "Score moyen", value: "34/40" },
              ].map((s) => (
                <div key={s.label} className="rounded-xl bg-slate-50 p-3 text-center">
                  <p className="text-lg font-bold text-slate-900">{s.value}</p>
                  <p className="text-xs text-slate-400">{s.label}</p>
                </div>
              ))}
            </div>
            <div className="mt-4 rounded-xl bg-brand/5 p-3">
              <p className="text-xs font-medium text-brand">⚡ Prochaine action</p>
              <p className="text-sm text-slate-700">Fais ta deuxième série pour terminer le bloc.</p>
            </div>
          </div>
        </div>
      </section>

      {/* TÉMOIGNAGES */}
      <section className="bg-white py-24">
        <div className="mx-auto max-w-6xl px-6">
          <div className="mb-12 text-center">
            <h2 className="text-3xl font-bold sm:text-4xl">Ils ont réussi</h2>
          </div>
          <div className="grid gap-6 sm:grid-cols-3">
            {TESTIMONIALS.map((t) => (
              <div key={t.name} className="rounded-2xl border border-slate-200 p-6">
                <div className="flex gap-1 text-yellow-400">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-current" />
                  ))}
                </div>
                <p className="mt-4 text-sm leading-relaxed text-slate-600">&ldquo;{t.text}&rdquo;</p>
                <div className="mt-4 flex items-center justify-between">
                  <p className="font-medium text-slate-900">{t.name}</p>
                  <span className="rounded-full bg-brand/10 px-2 py-0.5 text-sm font-bold text-brand">
                    {t.score}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA FINAL */}
      <section className="bg-brand py-20 text-center text-white">
        <div className="mx-auto max-w-2xl px-6">
          <h2 className="text-3xl font-bold sm:text-4xl">Prêt à réussir ton code ?</h2>
          <p className="mt-4 text-brand-light/80">
            Commence gratuitement. Passe premium quand tu veux. Résultats garantis.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <Link
              href="/auth/register"
              className="rounded-xl bg-white px-6 py-3.5 font-semibold text-brand shadow-md hover:bg-slate-50 transition-colors"
            >
              Commencer maintenant
            </Link>
            <Link
              href="/pricing"
              className="rounded-xl border border-white/40 px-6 py-3.5 font-semibold text-white hover:bg-white/10 transition-colors"
            >
              Voir les tarifs
            </Link>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-slate-200 py-8 text-center text-sm text-slate-400">
        <p>© {new Date().getFullYear()} Code Route · Tous droits réservés</p>
      </footer>
    </main>
  );
}
