"use client";
import { useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { CheckCircle } from "lucide-react";

const FEATURES_FREE = [
  "5 séries par mois",
  "Accès aux questions de base",
  "Score de préparation",
];

const FEATURES_PREMIUM = [
  "Séries illimitées",
  "540 questions (tous niveaux)",
  "Algorithme adaptatif complet",
  "Questions pièges identifiées",
  "Analyse détaillée des erreurs",
  "Score de préparation avancé",
  "Support prioritaire",
];

export default function PricingPage() {
  const { data: session } = useSession();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleCheckout() {
    if (!session) {
      router.push("/auth/register");
      return;
    }

    setLoading(true);
    setError("");

    try {
      const res = await fetch("/api/checkout", { method: "POST" });
      const data = await res.json();

      if (!res.ok || !data.url) {
        setError(data.error ?? "Erreur lors de la redirection vers le paiement.");
        setLoading(false);
        return;
      }

      window.location.href = data.url;
    } catch {
      setError("Erreur réseau. Réessaie.");
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-slate-50">
      <nav className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-4">
          <Link href="/" className="text-lg font-bold text-brand">Code Route</Link>
          <div className="flex gap-3">
            {session ? (
              <Link href="/dashboard" className="text-sm text-slate-600 hover:text-slate-900">Dashboard</Link>
            ) : (
              <>
                <Link href="/auth/login" className="text-sm text-slate-600 hover:text-slate-900">Connexion</Link>
                <Link href="/auth/register" className="rounded-lg bg-brand px-4 py-2 text-sm font-medium text-white">
                  Commencer
                </Link>
              </>
            )}
          </div>
        </div>
      </nav>

      <div className="mx-auto max-w-4xl px-6 py-20">
        <div className="text-center">
          <h1 className="text-4xl font-extrabold tracking-tight text-slate-900">
            Un tarif simple et transparent
          </h1>
          <p className="mt-3 text-slate-500">
            Commence gratuitement. Passe premium pour accéder à l&apos;ensemble du programme.
          </p>
        </div>

        {error && (
          <div className="mt-6 rounded-xl bg-red-50 px-4 py-3 text-center text-sm text-red-700">
            {error}
          </div>
        )}

        <div className="mt-12 grid gap-6 sm:grid-cols-2">
          {/* Free plan */}
          <div className="rounded-2xl border border-slate-200 bg-white p-8">
            <p className="text-sm font-medium text-slate-500">Gratuit</p>
            <p className="mt-2 text-4xl font-extrabold text-slate-900">0 €</p>
            <p className="text-slate-400">pour toujours</p>

            <ul className="mt-6 space-y-3">
              {FEATURES_FREE.map((f) => (
                <li key={f} className="flex items-center gap-2.5 text-sm text-slate-600">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 text-slate-400" />
                  {f}
                </li>
              ))}
            </ul>

            <Link
              href="/auth/register"
              className="mt-8 block w-full rounded-xl border border-slate-200 py-3 text-center text-sm font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
            >
              Commencer gratuitement
            </Link>
          </div>

          {/* Premium plan */}
          <div className="relative rounded-2xl border-2 border-brand bg-white p-8 shadow-lg">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2">
              <span className="rounded-full bg-brand px-3 py-1 text-xs font-semibold text-white">
                Recommandé
              </span>
            </div>

            <p className="text-sm font-medium text-brand">Premium</p>
            <p className="mt-2 text-4xl font-extrabold text-slate-900">19 €</p>
            <p className="text-slate-400">par mois · sans engagement</p>

            <ul className="mt-6 space-y-3">
              {FEATURES_PREMIUM.map((f) => (
                <li key={f} className="flex items-center gap-2.5 text-sm text-slate-700">
                  <CheckCircle className="h-4 w-4 flex-shrink-0 text-brand" />
                  {f}
                </li>
              ))}
            </ul>

            <button
              onClick={handleCheckout}
              disabled={loading}
              className="mt-8 w-full rounded-xl bg-brand py-3 text-sm font-semibold text-white hover:bg-brand-dark transition-colors disabled:opacity-60"
            >
              {loading ? "Redirection…" : "Passer à Premium"}
            </button>

            <p className="mt-3 text-center text-xs text-slate-400">
              Paiement sécurisé via Stripe · Annulation à tout moment
            </p>
          </div>
        </div>

        <p className="mt-12 text-center text-sm text-slate-400">
          Des questions ?{" "}
          <a href="mailto:support@coderoute.fr" className="text-brand hover:underline">
            Contacte-nous
          </a>
        </p>
      </div>
    </main>
  );
}
