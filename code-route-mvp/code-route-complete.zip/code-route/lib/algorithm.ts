export type AttemptInput = {
  difficulty: number;
  correct: boolean;
  slow: boolean;
  repeatedError: boolean;
};

/**
 * Calcule le delta de score de faiblesse pour un trapFamily donné.
 * - Mauvaise réponse → score augmente (piège non maîtrisé)
 * - Bonne réponse → score diminue légèrement
 * - Lent → pénalité supplémentaire
 * - Erreur répétée → malus additionnel
 */
export function weaknessDelta(input: AttemptInput): number {
  const base = 1 + 0.25 * (input.difficulty - 1);
  let score = 0;
  if (!input.correct) score += 3 * base;
  if (input.correct) score -= 1 * base;
  if (input.slow) score += 1 * base;
  if (!input.correct && input.repeatedError) score += 1.5 * base;
  return Number(score.toFixed(2));
}

/**
 * Score de préparation global de 0 à 100.
 * Basé sur la moyenne des examens, la maîtrise des pièges, la régularité et la vitesse.
 */
export function readinessScore(
  exams: number[],
  trapMastery: number,
  consistency: number,
  speed: number
): number {
  if (!exams.length) return 0;
  const avg = exams.reduce((a, b) => a + b, 0) / exams.length / 40;
  const raw = 100 * (0.55 * avg + 0.2 * trapMastery + 0.15 * consistency + 0.1 * speed);
  return Math.max(0, Math.min(100, Math.round(raw)));
}

/**
 * Label textuel du score de préparation.
 */
export function readinessLabel(score: number): string {
  if (score >= 88) return "Très prêt";
  if (score >= 80) return "Prêt";
  if (score >= 65) return "Presque prêt";
  return "Pas encore prêt";
}

/**
 * Détermine si une pause obligatoire doit être déclenchée.
 * Un bloc = 2 séries max avant pause.
 */
export function shouldForcePause(seriesCompletedInBlock: number): boolean {
  return seriesCompletedInBlock >= 2;
}
